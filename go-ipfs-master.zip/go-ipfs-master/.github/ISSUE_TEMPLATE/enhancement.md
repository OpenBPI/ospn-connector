---
name: 'Enhancement'
about: 'Suggest an improvement to an existing go-ipfs feature.'
labels: enhancement
---

<!--
Note: If you'd like to suggest an idea related to IPFS but not specifically related to the go implementation, please file an issue at https://github.com/ipfs/ipfs instead

When requesting an _enhancement_, please be sure to include your motivation and try to be as specific as possible.
-->
