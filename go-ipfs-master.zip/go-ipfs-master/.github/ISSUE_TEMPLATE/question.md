---
name: 'Question/Support'
about: 'DO NOT SELECT THIS OPTION: Ask questions on discuss.ipfs.io, IRC (#ipfs on freenode), or Matrix (#ipfs:matrix.org)'
labels: question
---

DO NOT ASK QUESTIONS HERE

This bug tracker is only for actionable bug reports and feature requests. Please direct any questions to https://discuss.ipfs.io or to our Matrix (#ipfs:matrix.org) or IRC (#ipfs on freenode) channels.

If you don't get an immediate response, please keep trying.
