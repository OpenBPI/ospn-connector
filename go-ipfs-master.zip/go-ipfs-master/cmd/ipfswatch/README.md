IPFSWatch monitors a directory and adds changes to IPFS

```
λ. ipfswatch --help
  -path=".": the path to watch
  -repo="": IPFS_PATH to use
```
