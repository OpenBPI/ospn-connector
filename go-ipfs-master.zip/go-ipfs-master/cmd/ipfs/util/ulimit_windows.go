// +build windows

package util

func init() {
	supportsFDManagement = false
}
