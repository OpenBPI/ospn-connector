# Assets loaded in with IPFS

## Generating docs

Do not edit the .go files directly.

Instead, edit the source files and use `go generate` from within the
assets directory:

```
go generate .
```
